package cn.com.web;

import cn.com.web.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnTouchListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * �����
 * 
 */
public class WebViewApp extends Activity {

	/** webview�ؼ� */
	private WebView webView;

	/** ��ǰurl��ַ */
	private String browserUrl = "file:///android_asset/error.html";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		// getWindow().requestFeature(Window.FEATURE_PROGRESS);// ��title bar��������
		// requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);// ��title
		setContentView(R.layout.browser_layout);
		initWebView();
	}

	/**
	 * ��ʼ��webview
	 */
	private void initWebView() {
		// �õ�webView������
		webView = (WebView) findViewById(R.id.browser_layout_webview);
		// ֧��JavaScript
		webView.getSettings().setJavaScriptEnabled(true);
		// ֧������
		webView.getSettings().setBuiltInZoomControls(true);
		// ֧�ֱ�������
		webView.getSettings().setSaveFormData(false);

		// �������
		webView.clearCache(true);
		// �����ʷ��¼
		webView.clearHistory();
		// ��������
		webView.loadUrl(browserUrl);
		// String baseUrl = "file:///android_asset";
		// webView.loadDataWithBaseURL(baseUrl, browserUrl, "text/html",
		// "utf-8", null);
		// ����
		webView.setWebViewClient(new WebViewClient() {

			/** ��ʼ����ҳ�� */
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				setProgressBarIndeterminateVisibility(true);// ���ñ������Ĺ�������ʼ
				browserUrl = url;
				super.onPageStarted(view, url, favicon);
			}

			/** �������¼� */
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				webView.loadUrl(url);
				return true;
			}

			/** ���󷵻� */
			@Override
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
			}

			/** ҳ��������� */
			@Override
			public void onPageFinished(WebView view, String url) {
				setProgressBarIndeterminateVisibility(false);// ���ñ������Ĺ�����ֹͣ
				super.onPageFinished(view, url);
			}

		});

		webView.setWebChromeClient(new WebChromeClient() {
			/** ���ý����� */
			public void onProgressChanged(WebView view, int newProgress) {
				// ���ñ������Ľ������İٷֱ�
				WebViewApp.this.getWindow().setFeatureInt(
						Window.FEATURE_PROGRESS, newProgress * 100);
				super.onProgressChanged(view, newProgress);
			}

			/** ���ñ��� */
			public void onReceivedTitle(WebView view, String title) {
				WebViewApp.this.setTitle(title);
				super.onReceivedTitle(view, title);
			}
		});
		webView.addJavascriptInterface(new RemoteInvokeService(WebViewApp.this,
				webView, "http://www.baidu.com/"), "js_invoke");
	}

	/**
	 * ���񷵻ؼ�
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack())) {
			webView.goBack();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

}
